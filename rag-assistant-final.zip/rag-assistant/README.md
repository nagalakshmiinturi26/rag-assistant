# ⚡ RAG Assistant — Production-Grade GenAI Chat

A full-stack AI chat assistant using Retrieval-Augmented Generation (RAG).
Built for the TrueAILab assignment.

---

## 🚀 Quick Start (Windows)

### Step 1 — Get a FREE Groq API key
1. Go to https://console.groq.com
2. Sign up (free, no credit card)
3. Click API Keys → Create API Key
4. Copy the key

### Step 2 — Open PowerShell in the project folder
1. Open the `rag-assistant` folder in File Explorer
2. Click the address bar, type `powershell`, press Enter

### Step 3 — Setup
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### Step 4 — Add your API key
```
notepad .env
```
Replace `your-groq-key-here` with your actual Groq key. Save and close.

### Step 5 — Run
```
uvicorn app.main:app --reload
```

### Step 6 — Open browser
Go to: http://localhost:8000

---

## 🏗️ Architecture

```
docs.json → Chunker → TF-IDF Embeddings → VectorStore (In-Memory)
                                                    |
User Query → Embed Query → Cosine Similarity Search → Top-K Chunks
                                                    |
                                             Prompt Builder
                                          (context + history + question)
                                                    |
                                          Groq LLM (llama-3.3-70b)
                                                    |
                                              Chat Response
```

## 📁 Project Structure

```
rag-assistant/
├── app/
│   ├── routes/chat.py         # API endpoints
│   ├── services/
│   │   ├── embeddings.py      # Local TF-IDF embeddings
│   │   ├── indexer.py         # Document indexing
│   │   ├── llm.py             # Groq/OpenAI/Gemini LLM calls
│   │   ├── retrieval.py       # Cosine similarity search
│   │   └── session.py         # Conversation history
│   ├── models/schemas.py      # Request/response models
│   ├── vectorstore/store.py   # In-memory vector store
│   ├── prompts/builder.py     # Prompt construction
│   ├── utils/
│   │   ├── config.py          # Settings from .env
│   │   ├── chunker.py         # Text chunking
│   │   └── logger.py          # Logging
│   └── main.py                # FastAPI app
├── frontend/
│   ├── index.html             # Chat UI
│   ├── styles.css             # Dark theme styles
│   └── app.js                 # Frontend logic
├── docs.json                  # 10-document knowledge base
├── requirements.txt
├── .env.example
└── README.md
```

## 🧠 RAG Explained

### Indexing (startup)
1. Load 10 documents from docs.json
2. Chunk each document into 400-word segments
3. Build TF-IDF embeddings (free, local, no API needed)
4. Store vectors in memory

### Querying (per message)
1. Embed the user question using TF-IDF
2. Cosine similarity search against all stored vectors
3. Filter chunks below similarity threshold (0.10)
4. Build prompt: context + history + question
5. Send to Groq LLM → return answer

### Cosine Similarity Formula
```
similarity = dot(a,b) / (|a| × |b|)
```

## 🔌 API

### POST /api/chat
```json
Request:  { "sessionId": "abc", "message": "How do I reset my password?" }
Response: { "reply": "...", "tokensUsed": 150, "retrievedChunks": 2, "sessionId": "abc" }
```

### GET /health
```json
{ "status": "healthy", "vectorstore_docs": 10, "llm_provider": "groq" }
```

## ✅ Features
- Real embedding-based RAG (no keyword search)
- Cosine similarity with threshold filtering
- Free local TF-IDF embeddings
- Groq LLM integration (free tier)
- Conversation history (last 5 pairs)
- Dark theme responsive chat UI
- Session management with localStorage
- Structured error handling
