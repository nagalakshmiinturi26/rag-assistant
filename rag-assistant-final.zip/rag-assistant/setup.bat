@echo off
echo ========================================
echo  RAG Assistant - Windows Setup
echo ========================================

echo.
echo [1/4] Creating virtual environment...
python -m venv venv
if errorlevel 1 (echo ERROR: Python not found. Install Python 3.10+ & retry. && pause && exit /b 1)

echo.
echo [2/4] Activating venv and installing packages...
call venv\Scripts\activate.bat
pip install -r requirements.txt
if errorlevel 1 (echo ERROR: pip install failed. && pause && exit /b 1)

echo.
echo [3/4] Checking .env file...
if not exist .env (
    copy .env.example .env
    echo  .env created from .env.example
    echo  ^> Open .env and paste your ANTHROPIC_API_KEY ^(or other LLM key^)
) else (
    echo  .env already exists - skipping
)

echo.
echo [4/4] Done!
echo.
echo  NEXT STEP: Edit .env and add your API key, then run:
echo.
echo    venv\Scripts\activate
echo    uvicorn app.main:app --reload
echo.
echo  Then open: http://localhost:8000
echo.
pause
