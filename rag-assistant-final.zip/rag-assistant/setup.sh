#!/usr/bin/env bash
set -e

echo "========================================"
echo " RAG Assistant - Mac/Linux Setup"
echo "========================================"

echo ""
echo "[1/4] Creating virtual environment..."
python3 -m venv venv

echo ""
echo "[2/4] Installing packages..."
source venv/bin/activate
pip install -r requirements.txt

echo ""
echo "[3/4] Checking .env file..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo " .env created from .env.example"
    echo " > Open .env and paste your ANTHROPIC_API_KEY (or other LLM key)"
else
    echo " .env already exists - skipping"
fi

echo ""
echo "[4/4] Done!"
echo ""
echo " NEXT STEP: Edit .env and add your API key, then run:"
echo ""
echo "   source venv/bin/activate"
echo "   uvicorn app.main:app --reload"
echo ""
echo " Then open: http://localhost:8000"
