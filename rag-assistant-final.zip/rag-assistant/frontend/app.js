/* ── State ─────────────────────────────────────────────────────────── */
const API_BASE = "";                     // same-origin; proxy in dev
const MAX_SESSIONS = 12;

let currentSessionId = null;
let sessions = {};                        // { sessionId: { title, messages[] } }
let isLoading = false;

/* ── DOM refs ──────────────────────────────────────────────────────── */
const messageInput = document.getElementById("message-input");
const sendBtn      = document.getElementById("send-btn");
const messagesEl   = document.getElementById("messages");
const sessionList  = document.getElementById("session-list");
const chatTitle    = document.getElementById("chat-title");
const statusDot    = document.getElementById("status-dot");
const statusText   = document.getElementById("status-text");
const welcomeEl    = document.getElementById("welcome");
const metaEl       = document.getElementById("chat-meta");
const sessionIdEl  = document.getElementById("session-id-display");

/* ── Persistence ────────────────────────────────────────────────────── */
function saveSessions() {
  try { localStorage.setItem("rag_sessions", JSON.stringify(sessions)); } catch {}
}

function loadSessions() {
  try {
    const raw = localStorage.getItem("rag_sessions");
    if (raw) sessions = JSON.parse(raw);
  } catch { sessions = {}; }
}

function generateId() {
  return "s_" + Math.random().toString(36).slice(2, 10);
}

/* ── Session management ─────────────────────────────────────────────── */
function createSession() {
  const id = generateId();
  sessions[id] = { title: "New conversation", messages: [] };
  currentSessionId = id;
  saveSessions();
  renderSessionList();
  renderMessages();
  if (sessionIdEl) sessionIdEl.textContent = id;
  return id;
}

function switchSession(id) {
  currentSessionId = id;
  if (sessionIdEl) sessionIdEl.textContent = id;
  renderMessages();
  renderSessionList();
  messageInput.focus();
}

function renderSessionList() {
  sessionList.innerHTML = "";
  const ids = Object.keys(sessions).reverse().slice(0, MAX_SESSIONS);
  ids.forEach(id => {
    const s = sessions[id];
    const el = document.createElement("div");
    el.className = "session-item" + (id === currentSessionId ? " active" : "");
    el.innerHTML = `<span class="session-item-icon">💬</span>${escHtml(s.title)}`;
    el.onclick = () => switchSession(id);
    sessionList.appendChild(el);
  });
}

function updateSessionTitle(id, firstMessage) {
  const title = firstMessage.length > 40
    ? firstMessage.slice(0, 40) + "…"
    : firstMessage;
  sessions[id].title = title;
  saveSessions();
  renderSessionList();
  chatTitle.textContent = title;
}

/* ── Message rendering ──────────────────────────────────────────────── */
function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatText(text) {
  // Very minimal Markdown-ish rendering
  return escHtml(text)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\n/g, "<br>");
}

function renderMessages() {
  if (!currentSessionId) { showWelcome(); return; }
  const session = sessions[currentSessionId];
  if (!session || session.messages.length === 0) { showWelcome(); return; }

  hideWelcome();
  messagesEl.innerHTML = "";

  session.messages.forEach(msg => {
    const el = buildMessageEl(msg);
    messagesEl.appendChild(el);
  });

  scrollToBottom();
}

function buildMessageEl({ role, text, meta }) {
  const wrap = document.createElement("div");
  wrap.className = `message ${role}`;

  const avatar = document.createElement("div");
  avatar.className = `avatar ${role}`;
  avatar.textContent = role === "user" ? "U" : "AI";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = formatText(text);

  if (meta && role === "bot") {
    const metaDiv = document.createElement("div");
    metaDiv.className = "bubble-meta";

    if (meta.tokensUsed)
      metaDiv.innerHTML += `<span class="token-badge">⚡ ${meta.tokensUsed} tokens</span>`;
    if (meta.retrievedChunks)
      metaDiv.innerHTML += `<span class="chunk-badge">📚 ${meta.retrievedChunks} chunks</span>`;
    if (meta.timestamp)
      metaDiv.innerHTML += `<span>${meta.timestamp}</span>`;

    bubble.appendChild(metaDiv);
  }

  wrap.appendChild(avatar);
  wrap.appendChild(bubble);
  return wrap;
}

function appendMessage(role, text, meta = null) {
  const session = sessions[currentSessionId];
  session.messages.push({ role, text, meta });
  saveSessions();

  hideWelcome();
  const el = buildMessageEl({ role, text, meta });
  messagesEl.appendChild(el);
  scrollToBottom();
}

function showTyping() {
  const wrap = document.createElement("div");
  wrap.className = "message bot";
  wrap.id = "typing-msg";

  const avatar = document.createElement("div");
  avatar.className = "avatar bot";
  avatar.textContent = "AI";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = `<div class="typing-indicator"><span></span><span></span><span></span></div>`;

  wrap.appendChild(avatar);
  wrap.appendChild(bubble);
  messagesEl.appendChild(wrap);
  scrollToBottom();
}

function removeTyping() {
  const el = document.getElementById("typing-msg");
  if (el) el.remove();
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

/* ── Welcome screen ─────────────────────────────────────────────────── */
function showWelcome() {
  if (welcomeEl) welcomeEl.style.display = "flex";
  messagesEl.innerHTML = "";
}

function hideWelcome() {
  if (welcomeEl) welcomeEl.style.display = "none";
}

/* ── Health check ───────────────────────────────────────────────────── */
async function checkHealth() {
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (res.ok) {
      const data = await res.json();
      setStatus("online", `API healthy · ${data.vectorstore_docs ?? "?"} vectors · ${data.llm_provider ?? ""}`);
    } else {
      setStatus("offline", "API unreachable");
    }
  } catch {
    setStatus("offline", "Cannot connect to backend");
  }
}

function setStatus(state, label) {
  statusDot.className = "status-dot " + (state === "offline" ? "offline" : state === "loading" ? "loading" : "");
  statusText.textContent = label;
}

/* ── Send message ────────────────────────────────────────────────────── */
async function sendMessage() {
  const text = messageInput.value.trim();
  if (!text || isLoading) return;

  if (!currentSessionId) createSession();
  if (sessions[currentSessionId].messages.length === 0) updateSessionTitle(currentSessionId, text);

  messageInput.value = "";
  autoResize();

  isLoading = true;
  sendBtn.disabled = true;
  setStatus("loading", "Thinking…");

  appendMessage("user", text);
  showTyping();

  try {
    const res = await fetch(`${API_BASE}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: currentSessionId, message: text }),
    });

    const data = await res.json();
    removeTyping();

    if (!res.ok) {
      appendMessage("bot", `⚠️ Error: ${data.error || data.detail || "Unknown error"}`);
    } else {
      const now = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      appendMessage("bot", data.reply, {
        tokensUsed: data.tokensUsed,
        retrievedChunks: data.retrievedChunks,
        timestamp: now,
      });
    }
    setStatus("online", "Ready");
  } catch (err) {
    removeTyping();
    appendMessage("bot", "⚠️ Network error. Is the backend running?");
    setStatus("offline", "Connection failed");
  }

  isLoading = false;
  sendBtn.disabled = false;
  messageInput.focus();
}

/* ── Suggestion chips ────────────────────────────────────────────────── */
function sendSuggestion(text) {
  messageInput.value = text;
  sendMessage();
}

/* ── Textarea auto-resize ───────────────────────────────────────────── */
function autoResize() {
  messageInput.style.height = "auto";
  messageInput.style.height = Math.min(messageInput.scrollHeight, 140) + "px";
}

/* ── Init ────────────────────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  loadSessions();

  // Boot — create a session if none exist
  const ids = Object.keys(sessions);
  if (ids.length === 0) {
    createSession();
  } else {
    currentSessionId = ids[ids.length - 1];
    renderSessionList();
    renderMessages();
    if (sessionIdEl) sessionIdEl.textContent = currentSessionId;
  }

  // Event listeners
  sendBtn.addEventListener("click", sendMessage);

  messageInput.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });

  messageInput.addEventListener("input", autoResize);

  document.getElementById("new-chat-btn").addEventListener("click", () => {
    createSession();
    messageInput.focus();
  });

  // Suggestion chips
  document.querySelectorAll(".suggestion").forEach(el => {
    el.addEventListener("click", () => sendSuggestion(el.dataset.q));
  });

  checkHealth();
  setInterval(checkHealth, 30000);
  messageInput.focus();
});
