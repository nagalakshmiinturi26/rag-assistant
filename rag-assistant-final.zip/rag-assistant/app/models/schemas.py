"""Pydantic models for request/response validation."""

from pydantic import BaseModel, Field, field_validator
from typing import Optional


class ChatRequest(BaseModel):
    sessionId: str = Field(..., min_length=1, description="Unique session identifier")
    message: str = Field(..., min_length=1, description="User message")

    @field_validator("message")
    @classmethod
    def message_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Message cannot be blank")
        return v.strip()

    @field_validator("sessionId")
    @classmethod
    def session_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("sessionId cannot be blank")
        return v.strip()


class ChatResponse(BaseModel):
    reply: str
    tokensUsed: int
    retrievedChunks: int
    sessionId: str


class HealthResponse(BaseModel):
    status: str
    vectorstore_docs: Optional[int] = None
    llm_provider: Optional[str] = None


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
