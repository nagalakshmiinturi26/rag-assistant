from __future__ import annotations
from dataclasses import dataclass
import httpx
from app.utils.config import get_settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
settings = get_settings()

@dataclass
class LLMResponse:
    content: str
    tokens_used: int

async def _call_groq(system: str, prompt: str) -> LLMResponse:
    headers = {
        "Authorization": f"Bearer {settings.groq_api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "llama-3.3-70b-versatile",
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
    content = data["choices"][0]["message"]["content"]
    tokens = data.get("usage", {}).get("total_tokens", 0)
    logger.info(f"[LLM/Groq] tokens_used={tokens}")
    return LLMResponse(content=content, tokens_used=tokens)

async def _call_openai(system: str, prompt: str) -> LLMResponse:
    headers = {
        "Authorization": f"Bearer {settings.openai_api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "gpt-4o-mini",
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ],
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
    content = data["choices"][0]["message"]["content"]
    tokens = data.get("usage", {}).get("total_tokens", 0)
    return LLMResponse(content=content, tokens_used=tokens)

async def _call_gemini(system: str, prompt: str) -> LLMResponse:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={settings.gemini_api_key}"
    payload = {
        "contents": [{"parts": [{"text": f"{system}\n\n{prompt}"}]}],
        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1024},
    }
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
    content = data["candidates"][0]["content"]["parts"][0]["text"]
    tokens = data.get("usageMetadata", {}).get("totalTokenCount", 0)
    return LLMResponse(content=content, tokens_used=tokens)

async def generate(system: str, prompt: str) -> LLMResponse:
    provider = settings.llm_provider.lower()
    logger.info(f"[LLM] provider={provider}")
    _providers = {
        "groq": _call_groq,
        "openai": _call_openai,
        "gemini": _call_gemini,
    }
    if provider not in _providers:
        raise ValueError(f"Unknown LLM provider: {provider!r}")
    try:
        return await _providers[provider](system, prompt)
    except httpx.HTTPStatusError as exc:
        status = exc.response.status_code
        if status == 401:
            raise RuntimeError(f"Invalid API key for provider '{provider}'.") from exc
        elif status == 429:
            raise RuntimeError(f"Rate limit exceeded for provider '{provider}'.") from exc
        else:
            raise RuntimeError(f"LLM API error {status}: {exc.response.text}") from exc
    except httpx.TimeoutException:
        raise RuntimeError(f"Request timed out.")
    except Exception as exc:
        logger.error(f"[LLM] Error: {exc}")
        raise
