"""
In-memory session manager for conversation history.
Stores up to MAX_HISTORY_PAIRS (user, assistant) message pairs per session.
"""

from __future__ import annotations

from collections import defaultdict
from typing import List, Tuple

from app.utils.config import get_settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
settings = get_settings()

# session_id -> list of (user_msg, assistant_msg)
_sessions: dict[str, List[Tuple[str, str]]] = defaultdict(list)


def get_history(session_id: str) -> List[Tuple[str, str]]:
    """Return the conversation history for a session."""
    return list(_sessions[session_id])


def add_turn(session_id: str, user_msg: str, assistant_msg: str) -> None:
    """Append a new turn and trim to MAX_HISTORY_PAIRS."""
    _sessions[session_id].append((user_msg, assistant_msg))
    max_pairs = settings.max_history_pairs
    if len(_sessions[session_id]) > max_pairs:
        _sessions[session_id] = _sessions[session_id][-max_pairs:]
    logger.debug(
        f"[Session] {session_id} history_length={len(_sessions[session_id])}"
    )


def clear_session(session_id: str) -> None:
    """Clear all history for a session."""
    _sessions.pop(session_id, None)
    logger.info(f"[Session] Cleared session {session_id}")
