"""
Indexing service: loads docs.json, chunks, embeds (local TF-IDF by default),
and populates the in-memory vector store.  Called once at startup.
"""

from __future__ import annotations

import json
from pathlib import Path

from app.services.embeddings import build_idf, embed_texts
from app.utils.chunker import chunk_text
from app.utils.config import get_settings
from app.utils.logger import get_logger
from app.vectorstore.store import VectorEntry, get_vector_store

logger = get_logger(__name__)
settings = get_settings()


async def index_documents(docs_path: str = "docs.json") -> None:
    """Load → chunk → embed → store all documents."""
    store = get_vector_store()
    if store.size() > 0:
        logger.info("[Indexer] Already indexed — skipping.")
        return

    path = Path(docs_path)
    if not path.exists():
        raise FileNotFoundError(f"docs.json not found at: {path.resolve()}")

    with open(path, "r", encoding="utf-8") as f:
        documents = json.load(f)

    logger.info(f"[Indexer] Loaded {len(documents)} documents")

    # Build chunk list
    all_chunks: list[dict] = []
    for doc in documents:
        title   = doc.get("title", "Untitled")
        content = doc.get("content", "")
        for idx, chunk in enumerate(chunk_text(content, settings.chunk_size, settings.chunk_overlap)):
            all_chunks.append({"chunk_id": f"{title}::chunk_{idx}",
                               "title": title, "content": chunk})

    logger.info(f"[Indexer] {len(all_chunks)} chunks to embed")

    # Build IDF from corpus (needed for local TF-IDF provider)
    provider = settings.embedding_provider.lower()
    if provider not in ("openai", "voyage"):
        build_idf([c["content"] for c in all_chunks])

    # Embed in batches of 20
    for start in range(0, len(all_chunks), 20):
        batch = all_chunks[start:start + 20]
        embeddings = await embed_texts([c["content"] for c in batch])
        for meta, emb in zip(batch, embeddings):
            store.add(VectorEntry(chunk_id=meta["chunk_id"],
                                  title=meta["title"],
                                  content=meta["content"],
                                  embedding=emb))

    logger.info(f"[Indexer] ✅ Done — {store.size()} vectors stored.")
