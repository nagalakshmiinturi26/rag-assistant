"""
Retrieval service: embed the user query and fetch top-K chunks above the
similarity threshold from the in-memory vector store.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from app.services.embeddings import embed_query
from app.utils.config import get_settings
from app.utils.logger import get_logger
from app.vectorstore.store import VectorEntry, get_vector_store

logger = get_logger(__name__)
settings = get_settings()


@dataclass
class RetrievedChunk:
    chunk_id: str
    title: str
    content: str
    score: float


async def retrieve(query: str) -> List[RetrievedChunk]:
    """
    Embed the query, run cosine similarity search, filter by threshold.

    Returns a list of RetrievedChunk objects (may be empty if nothing passes
    the similarity threshold).
    """
    store = get_vector_store()
    if store.size() == 0:
        logger.warning("[Retrieval] Vector store is empty — no chunks available.")
        return []

    query_embedding = await embed_query(query)
    raw_results = store.search(query_embedding, top_k=settings.top_k)

    chunks: List[RetrievedChunk] = []
    for entry, score in raw_results:
        logger.info(
            f"[Retrieval] chunk_id={entry.chunk_id} score={score:.4f} "
            f"threshold={settings.similarity_threshold}"
        )
        if score >= settings.similarity_threshold:
            chunks.append(
                RetrievedChunk(
                    chunk_id=entry.chunk_id,
                    title=entry.title,
                    content=entry.content,
                    score=score,
                )
            )

    logger.info(f"[Retrieval] {len(chunks)}/{settings.top_k} chunks passed threshold.")
    return chunks
