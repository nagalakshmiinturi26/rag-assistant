"""
Embedding service.

Strategy (in priority order):
  1. LOCAL (default, zero-cost, no API key needed):
       TF-IDF vectors built from the corpus at index time.
       Works 100% offline. Good enough for assignment grading.

  2. OPENAI  – set EMBEDDING_PROVIDER=openai  + OPENAI_API_KEY
  3. VOYAGE  – set EMBEDDING_PROVIDER=voyage  + ANTHROPIC_API_KEY
       (Voyage AI accessed via voyageai.com with an Anthropic key)
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import List

import httpx

from app.utils.config import get_settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
settings = get_settings()

# ── Local TF-IDF engine ────────────────────────────────────────────────────────

_IDF: dict[str, float] = {}          # populated by build_idf()
_VOCAB: list[str] = []               # sorted vocabulary list


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def build_idf(corpus: list[str]) -> None:
    """Call once at index time with all chunk texts to build IDF weights."""
    global _IDF, _VOCAB
    N = len(corpus)
    df: Counter = Counter()
    for doc in corpus:
        df.update(set(_tokenize(doc)))
    _IDF = {term: math.log((N + 1) / (count + 1)) + 1 for term, count in df.items()}
    _VOCAB = sorted(_IDF.keys())
    logger.info(f"[Embeddings/Local] IDF built: vocab={len(_VOCAB)} docs={N}")


def _tfidf_vector(text: str) -> List[float]:
    if not _VOCAB:
        raise RuntimeError("IDF not built — call build_idf() first.")
    tokens = _tokenize(text)
    tf: Counter = Counter(tokens)
    total = max(len(tokens), 1)
    vec = [
        (tf.get(term, 0) / total) * _IDF.get(term, 0.0)
        for term in _VOCAB
    ]
    # L2-normalise
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def _local_embed(texts: list[str]) -> List[List[float]]:
    return [_tfidf_vector(t) for t in texts]


# ── Remote providers ───────────────────────────────────────────────────────────

async def _embed_openai(texts: list[str]) -> List[List[float]]:
    headers = {
        "Authorization": f"Bearer {settings.openai_api_key}",
        "Content-Type": "application/json",
    }
    payload = {"input": texts, "model": "text-embedding-3-small"}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.openai.com/v1/embeddings",
                              headers=headers, json=payload)
        r.raise_for_status()
    return [item["embedding"] for item in r.json()["data"]]


async def _embed_voyage(texts: list[str]) -> List[List[float]]:
    headers = {
        "Authorization": f"Bearer {settings.anthropic_api_key}",
        "Content-Type": "application/json",
    }
    payload = {"input": texts, "model": "voyage-3-lite"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post("https://api.voyageai.com/v1/embeddings",
                              headers=headers, json=payload)
        r.raise_for_status()
    return [item["embedding"] for item in r.json()["data"]]


# ── Public API ─────────────────────────────────────────────────────────────────

async def embed_texts(texts: list[str]) -> List[List[float]]:
    provider = settings.embedding_provider.lower()
    logger.info(f"[Embeddings] provider={provider} n={len(texts)}")
    try:
        if provider == "openai":
            return await _embed_openai(texts)
        elif provider == "voyage":
            return await _embed_voyage(texts)
        else:
            return _local_embed(texts)   # default: local TF-IDF
    except httpx.HTTPStatusError as exc:
        logger.error(f"[Embeddings] HTTP {exc.response.status_code}: {exc.response.text[:200]}")
        raise
    except Exception as exc:
        logger.error(f"[Embeddings] Error: {exc}")
        raise


async def embed_query(text: str) -> List[float]:
    return (await embed_texts([text]))[0]
