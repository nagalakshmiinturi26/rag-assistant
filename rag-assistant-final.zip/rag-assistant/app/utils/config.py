from functools import lru_cache
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    llm_provider: str = "groq"
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    gemini_api_key: str = ""
    mistral_api_key: str = ""
    groq_api_key: str = ""
    embedding_provider: str = "local"
    chunk_size: int = 400
    chunk_overlap: int = 50
    top_k: int = 3
    similarity_threshold: float = 0.10
    app_env: str = "development"
    log_level: str = "INFO"
    cors_origins: str = "*"
    max_history_pairs: int = 5

    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "allow"

@lru_cache()
def get_settings() -> Settings:
    return Settings()
