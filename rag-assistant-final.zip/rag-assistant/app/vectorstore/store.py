"""
In-memory vector store using cosine similarity.

Each entry stores:
  - chunk_id    : str  – unique identifier
  - title       : str  – source document title
  - content     : str  – chunk text
  - embedding   : list[float] – dense embedding vector
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple

from app.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class VectorEntry:
    chunk_id: str
    title: str
    content: str
    embedding: List[float]


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    """Compute cosine similarity between two vectors."""
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = math.sqrt(sum(x * x for x in a))
    mag_b = math.sqrt(sum(x * x for x in b))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


class InMemoryVectorStore:
    def __init__(self) -> None:
        self._entries: List[VectorEntry] = []

    def add(self, entry: VectorEntry) -> None:
        self._entries.append(entry)

    def size(self) -> int:
        return len(self._entries)

    def search(
        self, query_embedding: List[float], top_k: int = 3
    ) -> List[Tuple[VectorEntry, float]]:
        """
        Return top-k entries sorted by cosine similarity (descending).
        Returns list of (entry, score) tuples.
        """
        scored = [
            (entry, _cosine_similarity(query_embedding, entry.embedding))
            for entry in self._entries
        ]
        scored.sort(key=lambda x: x[1], reverse=True)
        results = scored[:top_k]
        for entry, score in results:
            logger.debug(
                f"[VectorStore] chunk_id={entry.chunk_id} title='{entry.title}' score={score:.4f}"
            )
        return results


# Module-level singleton
_store: InMemoryVectorStore | None = None


def get_vector_store() -> InMemoryVectorStore:
    global _store
    if _store is None:
        _store = InMemoryVectorStore()
    return _store
