"""
FastAPI application entry point.
Startup: indexes documents into the vector store.
"""

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError

from app.routes.chat import router
from app.services.indexer import index_documents
from app.utils.config import get_settings
from app.utils.logger import get_logger

logger = get_logger(__name__)
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Index documents at startup."""
    logger.info("🚀 Starting RAG Assistant — indexing documents...")
    try:
        await index_documents()
    except Exception as exc:
        logger.error(f"❌ Indexing failed: {exc}")
    yield
    logger.info("Shutting down RAG Assistant.")


app = FastAPI(
    title="RAG Assistant API",
    description="Production-grade GenAI assistant with Retrieval-Augmented Generation.",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
origins = [o.strip() for o in settings.cors_origins.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Validation error handler
@app.exception_handler(ValidationError)
async def validation_exception_handler(request: Request, exc: ValidationError):
    first_error = exc.errors()[0]
    msg = first_error.get("msg", "Validation error")
    return JSONResponse(status_code=422, content={"error": msg})


# Generic 422 from FastAPI body parsing
@app.exception_handler(422)
async def unprocessable_handler(request: Request, exc):
    return JSONResponse(
        status_code=422,
        content={"error": "Invalid request payload. Check required fields."},
    )

# Routes
app.include_router(router)

# Serve frontend static files
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
