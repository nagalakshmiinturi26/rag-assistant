"""Prompt construction for RAG-grounded responses."""

from typing import List, Tuple

from app.services.retrieval import RetrievedChunk

SYSTEM_PROMPT = """You are a helpful, accurate assistant.
Answer questions ONLY using the provided context.
If the context does not contain enough information, say so honestly.
Do not fabricate facts. Be concise and friendly."""

FALLBACK_RESPONSE = (
    "I could not find enough information in the knowledge base to answer this question. "
    "Please try rephrasing or contact support for further help."
)


def build_prompt(
    query: str,
    chunks: List[RetrievedChunk],
    history: List[Tuple[str, str]],
) -> str:
    """
    Construct the full user-turn prompt that includes:
      1. Retrieved context
      2. Conversation history
      3. User question

    Args:
        query: Current user question.
        chunks: Retrieved knowledge-base chunks.
        history: List of (user_msg, assistant_msg) pairs (oldest first).

    Returns:
        Formatted prompt string for the LLM user turn.
    """
    context_parts = []
    for i, chunk in enumerate(chunks, 1):
        context_parts.append(
            f"[Source {i}: {chunk.title}]\n{chunk.content}"
        )
    context_block = "\n\n".join(context_parts) if context_parts else "No relevant context found."

    history_lines = []
    for user_msg, assistant_msg in history:
        history_lines.append(f"User: {user_msg}")
        history_lines.append(f"Assistant: {assistant_msg}")
    history_block = "\n".join(history_lines) if history_lines else "None"

    prompt = (
        f"Use ONLY the provided context to answer the question.\n\n"
        f"Context:\n{context_block}\n\n"
        f"Conversation History:\n{history_block}\n\n"
        f"Question: {query}"
    )
    return prompt
