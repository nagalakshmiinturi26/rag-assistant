from fastapi import APIRouter, HTTPException
from app.models.schemas import ChatRequest, ChatResponse, HealthResponse
from app.prompts.builder import FALLBACK_RESPONSE, SYSTEM_PROMPT, build_prompt
from app.services.llm import generate
from app.services.retrieval import retrieve
from app.services.session import add_turn, get_history
from app.utils.config import get_settings
from app.utils.logger import get_logger
from app.vectorstore.store import get_vector_store

router = APIRouter()
logger = get_logger(__name__)
settings = get_settings()

@router.get("/health", response_model=HealthResponse)
async def health_check():
    store = get_vector_store()
    return HealthResponse(status="healthy", vectorstore_docs=store.size(), llm_provider=settings.llm_provider)

@router.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    session_id = request.sessionId
    user_message = request.message
    logger.info(f"[Chat] session={session_id} message='{user_message[:80]}'")
    try:
        chunks = await retrieve(user_message)
    except Exception as exc:
        logger.error(f"[Chat] Retrieval error: {exc}")
        raise HTTPException(status_code=502, detail=f"Retrieval failed: {exc}")
    if not chunks:
        add_turn(session_id, user_message, FALLBACK_RESPONSE)
        return ChatResponse(reply=FALLBACK_RESPONSE, tokensUsed=0, retrievedChunks=0, sessionId=session_id)
    history = get_history(session_id)
    prompt = build_prompt(user_message, chunks, history)
    try:
        llm_response = await generate(SYSTEM_PROMPT, prompt)
    except RuntimeError as exc:
        logger.error(f"[Chat] LLM error: {exc}")
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error(f"[Chat] Unexpected error: {exc}")
        raise HTTPException(status_code=500, detail=str(exc))
    reply = llm_response.content
    add_turn(session_id, user_message, reply)
    return ChatResponse(reply=reply, tokensUsed=llm_response.tokens_used, retrievedChunks=len(chunks), sessionId=session_id)
